# `@danklab/ui-comps`

Shared React + Tailwind v4 UI primitives for DankLab operational apps.

## Install

The package is currently distributed as a versioned npm package artifact while the private npm
scope is being provisioned. Use the tarball attached to the GitHub release (or create the same
checked artifact with `npm pack`), commit it to the consumer's `vendor/` directory, and install that
immutable file:

```sh
npm install --save-exact ./vendor/danklab-ui-comps-0.3.0.tgz
```

This keeps CI and deployment independent of sibling checkouts and private cross-repository
credentials. A consumer-relative `file:` dependency on the package directory is supported only for
local development.

### Styling: keep your app's branding (recommended)

Do **not** import `@danklab/ui-comps/styles.css` in an app that has its own brand theme.
That file is pre-compiled with DankLab's own `@theme` values baked into the utility classes,
so importing it overrides your app's colors. Instead, let your app's own Tailwind build
generate the utilities from *your* tokens by scanning the package distribution in your `index.css`:

```css
@import "tailwindcss";
/* your own @theme { --color-accent: ...; } tokens here */

/* Generate utilities for ui-comps components from this app's tokens */
@source "../node_modules/@danklab/ui-comps/dist";
```

Because the shared components reference semantic token *names* (`bg-card`, `text-foreground`,
`ring-accent`, …), they inherit your branding automatically. See `docs/adoption.md` for the
minimum set of tokens each app must define.

If you have **no** brand theme and just want DankLab's look, you can instead import the
compiled stylesheet once in your entry point:

```ts
import "@danklab/ui-comps/styles.css";
```

For app migrations, prefer a local adapter barrel such as `src/components/ui/index.ts` and re-export
components from this package. That keeps app code stable while the shared library evolves.

```ts
export {
  Badge,
  Button,
  Card,
  EmptyState,
  ErrorState,
  FormField,
  Input,
  LoadingState,
  MetricCard,
  PageHeader,
  Select,
  StatusBadge,
  Table,
  Toolbar,
} from "@danklab/ui-comps";
```

## Included components

- Core primitives: `Button`, `IconButton`, `Badge`, `StatusBadge`, `Card`, `Checkbox`, `Input`, `Select`, `FormField`.
- Feedback and overlays: `Modal`, `ConfirmDialog`, `Toast`, `ToastStack`, `ContextMenu*`,
  `DropdownMenu`, `Popover`, and `Tooltip`.
- Navigation/data: `Tabs`, `Table`.
- Operational patterns: `PageHeader`, `Toolbar`, `EmptyState`, `ErrorState`, `LoadingState`, `MetricCard`, `BigNumber`.
- Content/diagnostics: `MarkdownContent`, `CodeBlock`, `LogViewer`.
- Overlay behavior: `useDialogLayer` and `useAnchoredPopupPosition` for specialized consumer
  surfaces that need the same focus, isolation, and viewport contracts.

## Theme

The stylesheet includes Tailwind v4 theme tokens from `@danklab/tokens` and markdown styles for `.doc-content`.
Dark mode works with either `data-theme="dark"` on `:root` or a `.dark` class.

Useful semantic tokens include:

- colors: `background`, `foreground`, `card`, `border`, `muted`, `accent`, `positive`, `negative`, `warning`, `info`.
- surfaces: `surface`, `surface-raised`, `surface-muted`, `overlay`, `code-background`, `code-foreground`.
- runtime CSS variables: `--shadow-card`, `--shadow-popover`, `--shadow-dialog`, `--radius-*`, `--spacing-*`.

## LLM generation contract

Use `docs/llm-ui-generation-spec.yaml` as the compact, machine-readable design brief for generated DankLab UI. It distills the project standards into:

- WCAG 2.2 AA + WAI-ARIA APG accessibility rules.
- semantic token usage for color, radius, spacing, and elevation.
- component-level rules for buttons, forms, tables, tabs, dialogs, feedback, and content surfaces.
- testing expectations for labels, descriptions, keyboard behavior, and UI states.

Generated UI should prefer the exported primitives and token utilities before adding new raw markup or hardcoded style values.

## Scripts

```bash
npm run typecheck
npm run build
npm run check
```

Run the complete release gate with `npm run check`. Component tests use Vitest and the interactive catalog uses Ladle (`npm run stories`).
